<?php
require_once 'config.php';
$bdd = db_easyplanet_morder_backend::getInstance();
if(isset($_GET['email'],$_GET['key']) AND !empty(['email']) AND !empty($_GET['key'])){
    $email= htmlspecialchars( urldecode($_GET['email']));
    $key= intval($_GET['key']);
    
    $requser = $bdd->prepare("SELECT*FROM users WHERE email= ? AND confirmkey=?");
    $requser-> execute(array($email, $key));
    $userexist= $requser-> rowcount();

    if($userexist == 0){
       echo "Your account is now confirmed";
    } else {
        echo "Your account doesnt exist";
    }
     }

?>

