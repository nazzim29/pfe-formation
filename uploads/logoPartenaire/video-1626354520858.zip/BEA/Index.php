<html>
    <head>
        <title> signup click and click</title>
        <link rel="stylesheet" type="text/css" href="style1.css">
    </head>

    <body>
        <div id="login-box" >
            <div class="signup-box" >
                <span class ="signupwith" > Let's sign
                </span> </br>
                <button class="social facebook">By Facebook</button> </br>
                <button class="social google">By Google</button> </br>
                <a href="signup.php"><button class="email">By email</button></a> </br>  
                <p>Already have an account? <a href="login.php"> Sign in</a> </p>
            </div>
  
        </div> 
       
<style>
    body
{
margin: 0;
padding: 0; 
background: #efefef;
font-size: 16px;
color: #777;
font-family: sans-serif;
font-weight: 300; 

}
#login-box
{
position: relative;
margin: 5% auto;
height: 400px;
background: #fff;
box-shadow: 0 2px 4px rgba(0,0,0,0.6)
}
.signup-box
{
    position: absolute;
    top: 0;
    left: 0;
    box-sizing: border-box;
    padding: 40px;
    width: 300px;
    height: 400px;
}
</style>





    </body>



</html>