<?php
session_start();
sesson_destroy();
header('Location: index.php');
die();
