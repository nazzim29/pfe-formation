<?php
  require_once 'pdo_signup.php';

  db_easyplanet_morder_backend::setConfig('mysql:host=localhost;dbname=easyplanet_morder_backend;', 'root', '');
?>