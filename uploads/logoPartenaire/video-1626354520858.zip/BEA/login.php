<?php
session_start();
require_once 'config.php';
$bdd = db_easyplanet_morder_backend::getInstance();
if (isset($_POST['formconnect']))
{
    $emailconnect = htmlspecialchars($_POST['emailconnect']);
    $passwordconnect= sha1($_POST['passwordconnect']);
    if(!empty($emailconnect) AND !empty($passwordconnect))
    {
        $requser = $bdd ->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
        $requser -> execute (array($emailconnect, $passwordconnect));
        $userexist = $requser -> rowCount();
        if ($userexist == 1)
        {
            $userinfo = $requser -> fetch;
            $_SESSION['id'] = $userinfo ['id'];
            $_SESSION ['firstname']= $userinfo ['firstname'];
            $_SESSION ['lastname'] = $userinfo ['lastname'];
            $_SESSION ['email'] = $userinfo ['email'];
            header("Location: landing.php?id=".$_SESSION['id']);
        }
        else 
        {
            $alert ="Wrong email or password";
        }
    }
    else 
    {
        $alert = "All the fields must be completed";
    }
}
?>
<html>
    <head>
        <title>Click and collect</title>
        <meta charset=utf-8>
</head>
<body>
    <div align="center">
        <h2> Sign in</h2>
        <br/><br/>
        <form method="POST" action="">
           <input type="email" name= "emailconnect" placeholder="Email"/>
           <input type="password" name= "passwordconnect" placeholder="Password"/>
           <input type="submit" name= "formconnect" value="Sign in" />
</form>   
    <?php
     if(isset($alert))
     {
        echo '<font color="red">'.$alert."</font>";
     }
    ?>
</body>
</html>
