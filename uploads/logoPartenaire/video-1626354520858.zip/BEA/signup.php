<?php
require_once 'config.php';
$bdd = db_easyplanet_morder_backend::getInstance();
if(isset($_POST['formsignup']))
{
    $lastname= htmlspecialchars($_POST['lastname']);
        $firstname= htmlspecialchars($_POST['firstname']);
        $email= htmlspecialchars($_POST['email']);
        $password= sha1($_POST['password']);
        $password2= sha1($_POST['password2']);
    if(!empty($_POST['lastname']) AND !empty($_POST['firstname']) AND !empty($_POST['email']) AND!empty($_POST['password']) AND !empty($_POST['password2']))
    {
        

        $lastnamelenght= strlen($lastname);
        if ($lastnamelenght<=255)
        {
            if(filter_var($email, FILTER_VALIDATE_EMAIL))
            if ($password == $password2)
            {
                $lenghtkey= 12;
                $key="";
                for ($i=1;$i<$lenghtkey;$i++){
                    $key .=mt_rand(0,9);
                }
                $insertuser= $bdd->prepare("INSERT INTO users (firstname, lastname, email, password,confirmkey) VALUES (?,?,?,?,?)");
                $insertuser-> execute (array($firstname, $lastname, $email, $password, $key));
                $header="MIME-Version: 1.0\r\n";
                $header.='From: "Easyplanet"<contact@easyplanet.fr>'."\n";
                $header.='Content-Type:text/html; charset="utf-8"'."\n";
                $header.='Content-Transfer-Encoding: 8bit';

                $message='
                <html>
                    <body>
                    <div align="center">
                    <a href= "http://localhost/signupvalidation.php?email='.urlencode($email).'&key='.$key.'">Confirm your account</a>

                    </div>
                    </body>
                    </html>
                    ';
                    mail($email,"Verify your account",$message,$header);
                                    $alert = "Your sign up is done !";
                                }
                                else 
                                {
                                    $alert = "Your passwords are different";
                                }
                                else 
                                {
                                    $alert =" Your adresse mail is not valid";
                                }
                            }
                            
                            }
                        else 
                            {
                            $alert= "All the fields must be completed";
                            }

                    }
?>
<html>
    <head>
        <title>Click and collect</title>
        <meta charset=utf-8>
</head>
<body>
    <div align="center">
        <h2> Sign Up</h2>
        <br/><br/>
        <form method="POST" action="">
            <table>
                <tr>
                <td>
                    <label for="lastname">Last name :</label>
</td>
<td> 
    <input type="text" placeholder="Your last name" id="lastname" name="lastname" value =" <?php if(isset($lastname)) {echo $lastname; } ?>" />
</td>
</tr>
<tr>
                <td>
                    <label for="firstname">First name :</label>
</td>
<td> 
    <input type="text" placeholder="Your first name" id="firstname" name="firstname"/>
</td>
</tr>
<tr>
                <td>
                    <label for="email">E-mail:</label>
</td>
<td> 
    <input type="text" placeholder="Your E-mail" id="email" name="email"/>
</td>
</tr>
<tr>
                <td>
                    <label for="password">Password:</label>
</td>
<td> 
    <input type="password" placeholder="Your password" id="password" name="password"/>
</td>
</tr>
<tr>
                <td>
                    <label for="password2">Retype your password :</label>
</td>
<td> 
    <input type="password" placeholder="Please retype your password" id="password2" name="password2"/>
</td>
</tr>
<tr>
    <td></td>
    <td align="center"> 
</br>
    <input type="submit" name= "formsignup" value="Sign Up"/>
</td>
</tr>
</table>
</form>   
    <?php
     if(isset($alert))
     {
        echo '<font color="red">'.$alert."</font>";
     }
    ?>
</body>
</html>
