<?php 
    require_once 'config.php';
    $bdd = db_easyplanet_morder_backend::getInstance();
    if(!empty($_POST['firstname']) && !empty($_POST['lastname'])&& !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['password_retype']))
    {
        $firstname = htmlspecialchars($_POST['firstname']);
        $lastname = htmlspecialchars($_POST['lastname']);
        $email = htmlspecialchars($_POST['email']);
        $password = htmlspecialchars($_POST['password']);
        $password_retype = htmlspecialchars($_POST['password_retype']);
        

        $check = $bdd->prepare('SELECT firstname, lastname, email, password FROM users WHERE email = :email');
        
        $check->execute(array('email'=> $email));
        $data = $check->fetch();
        $row = $check->rowCount();

        if($row == 0){ 
                if(strlen($email) <= 100){
                    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
                        if($password == $password_retype){

                            $cost = ['cost' => 12];
                            $password = password_hash($password, PASSWORD_BCRYPT, $cost);
                            
                            $ip = $_SERVER['REMOTE_ADDR'];
                           

                            $insert = $bdd->prepare('INSERT INTO users(firstname, lastname, email, password, ip) VALUES(:firstname, :lastname, :email, :password, :ip)');
                            $insert->execute(array(
                                'firstname' => $firstname,
                                'lastname' => $lastname,
                                'email' => $email,
                                'password' => $password,
                                'ip' => $ip,
                            ));

                            header('Location:signup.php?reg_err=success');
                            die();
                        }else{ header('Location: signup.php?reg_err=password'); die();}
                    }else{ header('Location: signup.php?reg_err=email'); die();}
                }else{ header('Location: signup.php?reg_err=email_length'); die();}
        
        }else{ header('Location: signup.php?reg_err=already'); die();}
    }
    

             

