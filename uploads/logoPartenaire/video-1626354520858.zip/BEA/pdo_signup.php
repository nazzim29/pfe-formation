<?php
  final class db_easyplanet_morder_backend{
    private static $PDOInstance = null;
    private static $dsn         = null;
    private static $username    = null;
    private static $password    = null;
   

    private function __construct(){
    }

    public static function getInstance(){
      if(is_null(self::$PDOInstance)){

        if(self::configDone()){
          self::$PDOInstance = new PDO(self::, self::$username, self::$password, self::$options);
        }else{
          throw new Exception(__CLASS__." : no config for local db!");
        }
      }
      return self::$PDOInstance;
    }

    public static function setConfig($dsn, $username, $password, array $options = array()){
      self::$dsn      = $dsn;
      self::$username = $username;
      self::$password = $password;
      self::$options += $options;
    }

    private static function {
      return self::$dsn !== null && self::$username !== null && self::$password !== null;
    }
  }
?>